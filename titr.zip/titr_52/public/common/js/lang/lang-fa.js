//validation
var langValidation = {
  //Signup form validation
    name_required: 'نام الزامی است',
    name_minChars: 'نام نباید کنتر از 3 حرف باشد',
    family_required: 'نام خانوادگی الزامی است',
    family_minChars: 'نام خانوادگی نمی تواند کمتر از 3 حرف باشد',
    state_required: 'انتخاب استان الزامی است',
    mobile_required: 'تلفن همراه الزامی است',
    mobile_digit: 'تلفن همراه فقط می تواند شامل عدد باشد',
    mobile_minLength: 'تلفن همراه با 11 رقمی باشد' ,
    email_format: 'فرمت ایمیل وارده شده صحیح نمی باشد',
    username_required: 'نام کاربری الزامی است',
    username_minChars: 'نام کاربری کمتر از 5 حرف مجاز نیست',
    password_required: 'کلمه عبور الزامی است',
    password_minChars: 'طول کلمه عبور نباید کمتر از 8 حرف باشد'
    
    //Signin form validation



};
//error
var langError = {

};
