// langValidation in common/js/lang/lang-fa.js
$(document).ready(function() {
  $('#signupForm').formValidation({
    framework: 'bootstrap',
    icon: {
      valid: 'fa fa-valid fa-check',
      invalid: 'fa fa-valid fa-remove',
      validating: 'glyphicon glyphicon-refresh'
    },
    fields: {
      name: {
        validators: {
          notEmpty: {
            message: langValidation.name_required
          },
          stringLength: {
            min: 3,
            message: langValidation.name_minChars
          },
        }
      },
      family: {
        validators: {
          notEmpty: {
            message: langValidation.family_required
          },
          stringLength: {
            min: 3,
            message: langValidation.family_minChars
          },
        }
      },
      state: {
        validators: {
          notEmpty: {
            message: langValidation.state_required
          }
        }
      },
      mobile: {
        validators: {
          notEmpty: {
            message: langValidation.mobile_required
          },
          digits: {
            message: langValidation.mobile_digit
          },
          stringLength: {
            min: 11,
            message: langValidation.mobile_minLength
          },
        }
      },
      email: {
        validators: {
          emailAddress: {
            message: langValidation.email_format
          }
        }
      },
      username: {
        validators: {
          notEmpty: {
            message: langValidation.username_required
          },
          stringLength: {
            min: 5,
            message: langValidation.username_minChars
          },
        }
      },
      password: {
        validators: {
          notEmpty: {
            message: langValidation.password_required
          },
          stringLength: {
            min: 8,
            message: langValidation.password_minChars
          },
        }
      }
    }
  });

  $('#signinForm').formValidation({
    framework: 'bootstrap',
    icon: {
      valid: 'fa fa-valid fa-check',
      invalid: 'fa fa-valid fa-remove',
      validating: 'glyphicon glyphicon-refresh'
    },
    fields: {
      username: {
        validators: {
          notEmpty: {
            message: langValidation.username_required
          },
          stringLength: {
            min: 5,
            message: langValidation.username_minChars
          },
        }
      },

      password: {
        validators: {
          notEmpty: {
            message: langValidation.password_required
          },
          stringLength: {
            min: 8,
            message: langValidation.password_minChars
          },
        }
      }
    }
  });
});
