<?php

namespace Titr\Http\Controllers;

use Titr\State;
use Illuminate\Http\Request;

use Titr\Http\Requests;

class stateController extends Controller
{
    public function stateFetch()
    {
        $states = State::all();
        return $states;
    }
}
