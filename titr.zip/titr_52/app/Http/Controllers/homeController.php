<?php

namespace Titr\Http\Controllers;

use Illuminate\Http\Request;

use Titr\Http\Requests;

class homeController extends Controller
{
    public function index(){

      return view('frontend/homepage/index');

    }
}
