<?php

namespace Titr\Http\Controllers;

use Auth;
use Titr\User;
use Illuminate\Http\Request;
use Titr\Http\Requests;
use Titr\Http\Controllers;

class authController extends Controller
{
  public function getSignup()
  {
    $states = new stateController;
    $states = $states->stateFetch();
    return view('frontend/auth/register/index',compact('states'));
  }

  public function postSignup(Request $request)
  {
    $this->validate($request,[
      'name'     => 'required|min:3|max:100',
      'family'   => 'required|min:3|max:100',
      'state'    => 'required',
      'username' => 'required|min:3|max:100|alpha_dash|unique:users',
      'password' => 'required|min:6|max:32',
      'mobile'   => 'required|between:11,11',
      'email'    => 'email',
    ]);

    User::create([
      'name'     => $request->input('name'),
      'state_id' => $request->input('state'),
      'family'   => $request->input('family'),
      'username' => $request->input('username'),
      'password' => bcrypt($request->input('password')),
      'mobile'   => $request->input('mobile'),
      'email'    => $request->input('email'),
    ]);
    return redirect()
    ->route('auth.signin')
    ->with('register',__('register_successfully'));
  }

  public function getSignin()
  {
    return view ('frontend/auth/login/index');
  }

  public function postSignin(Request $request)
  {
    $this->validate($request,[
      'username'=>'required',
      'password'=>'required',
    ]);

    if(!Auth::attempt($request->only(['username','password']),$request->has('remember')))
    {
      return redirect()->back()->with('info',__('username_or_password_is_invalid'));
    }

    $username = new User();
    $username = $username->checkUsernameIsActive($request->input('username'));

    if(!$username == true)
    {
      return redirect()->back()->with('info',__('your_account_is_deactive'));
    }
    return redirect()->route('home')->with('info',__('welcome_to_titr'));

  }

  public function checkUsername(Request $request)
  {
    if ($request->ajax()){
      $result = [];
      $username = new User();
      $username = $username->checkUsername($request->input('username'));
      if(!is_null($username))
      {
        $result['message'] = 'failed';
        echo json_encode($result);
        exit;
      }else{
        $result['message'] = 'success';
        echo json_encode($result);
        exit;
      }
    }
  }

  public function getSignout(){
    Auth::logout();
    return redirect()->route('home');
  }
}
