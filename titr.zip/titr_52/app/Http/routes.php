<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/',[
  'uses' => 'homeController@index',
  'as' => 'home'
]);


Route::get('/user/signup',[
  'uses' => 'authController@getSignup',
  'as' => 'auth.signup'
]);

Route::post('/user/signup',[
  'uses' => 'authController@postSignup',
]);

Route::get('/user/signin',[
  'uses' => 'authController@getSignin',
  'as' => 'auth.signin'
]);

Route::post('/user/signin',[
  'uses' => 'authController@postSignin',
]);

Route::post('/userNameCheck',[
  'uses' => 'authController@checkUsername',
  'as'   => 'auth.userNameCheck'
]);

Route::get('/user/logout',[
  'uses' => 'authController@getSignout',
  'as'   => 'auth.signout'
]);
