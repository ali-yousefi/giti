<?php

namespace Titr;

use Illuminate\Database\Eloquent\Model;

class State extends Model
{
    protected $table = 'state';

    public $fillable = [
        'name',
        'active'
    ];
}
