<?php

namespace Titr\Events;

abstract class Event
{
    //
}
