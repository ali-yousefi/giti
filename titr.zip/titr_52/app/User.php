<?php

namespace Titr;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{

  /**
  * The attributes that are mass assignable.
  *
  * @var array
  */
  protected $fillable = [
    'state_id',
    'name',
    'family',
    'username',
    'password',
    'email',
    'mobile',
    'created_at',
    'updated_at'
  ];

  /**
  * The attributes that should be hidden for arrays.
  *
  * @var array
  */
  protected $hidden = [
    'password',
    'remember_token'
  ];

  public function checkUsername($username)
  {
    if(isset($username))
    {
      $username = User::where('username',$username)->first();
      return $username;
    }
  }

  public function checkUsernameIsActive($username)
  {
    if(isset($username))
    {
      $username = User::where('username',$username)
      ->where('active', true)->first();
      if(!is_null($username))
      {
        return true;
      }
        return false;
    }
  }



}
