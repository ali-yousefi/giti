<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <title>یک تیتر | ثبت نام</title>
    <?php echo e(Html::style('common/css/bootstrap/bootstrap.min.css')); ?>

    <?php echo e(Html::style('common/css/bootstrap/bootstrap-rtl.min.css')); ?>

    <?php echo e(Html::style('common/css/font-awesome/font-awesome.min.css')); ?>

    <?php echo e(Html::style('common/css/iransans/style.css')); ?>

    <?php echo e(Html::style('frontend/css/auth/signup/signup.css')); ?>

</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="col-md-4 col-lg-offset-4">
                    <div class="register-wrapper">
                        <div class="icon">
                            <img src="<?php echo e(asset('frontend/img/signup/icon.svg')); ?>" alt="" />
                            <h3>ورود به پنل کاربری</h3>
                        </div>
                        <div class="form">
                            <form class="form" role="form" method="POST" action="<?php echo e(route('auth.signin')); ?>" id="signinForm">
                                <div class="form-group username">
                                    <input type="text" name="username" class="form-control text-left" id="username" placeholder="نام کاربری">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" placeholder="رمز عبور" class="form-control text-left" id="pwd">
                                </div>
                                <div class="checkbox">
                                    <label><input type="checkbox">من را بخاطر نگه دار</label>
                                </div>
                                <button type="submit" class="btn btn-success btn-block">ورود</button>
                                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo e(Html::script('common/js/jquery/jquery.min.js')); ?>

    <?php echo e(Html::script('common/js/bootstrap/bootstrap.min.js')); ?>

    <?php echo e(Html::script('common/js/validator/formValidation.min.js')); ?>

    <?php echo e(Html::script('common/js/validator/bootstrapValidation.min.js')); ?>

    <?php echo e(Html::script('common/js/lang/lang-fa.js')); ?>

    <?php echo e(Html::script('frontend/js/auth/auth.js')); ?>

</body>
</html>
