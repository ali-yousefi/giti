<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <title>یک تیتر | ثبت نام</title>
    <?php echo e(Html::style('common/css/bootstrap/bootstrap.min.css')); ?>

    <?php echo e(Html::style('common/css/bootstrap/bootstrap-rtl.min.css')); ?>

    <?php echo e(Html::style('common/css/font-awesome/font-awesome.min.css')); ?>

    <?php echo e(Html::style('common/css/iransans/style.css')); ?>

    <?php echo e(Html::style('frontend/css/auth/signup/signup.css')); ?>

    <?php echo e(Html::style('common/css/validator/formValidation.min.css')); ?>

</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="col-md-4 col-lg-offset-4">
                    <div class="register-wrapper">
                        <div class="icon">
                            <img src="<?php echo e(asset('frontend/img/signup/icon.svg')); ?>" alt="" />
                            <h3>ثبت نام در یک تیتر</h3>
                        </div>
                        <div class="form">
                            <form action="<?php echo e(route('auth.signup')); ?>" method="POST" class="form" id="signupForm">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?> ">
                                    <input type="text" name="name" class="form-control" id="name" placeholder="نام" value="<?php echo e(Request::old('name') ?: ''); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('name')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('family') ? 'has-error' : ''); ?> ">
                                    <input type="text" name="family" class="form-control" id="family" placeholder="نام خانوادگی" value="<?php echo e(Request::old('family') ?: ''); ?>">
                                    <?php if($errors->has('family')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('family')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('state') ? 'has-error' : ''); ?> ">
                                    <select class="form-control" name="state">
                                        <option value="">-- انتخاب کنید --</option>
                                        <?php foreach($states as $state): ?>
                                            <option value="<?php echo e($state->id); ?>" ><?php echo e($state->name); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if($errors->has('state')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('state')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('mobile') ? 'has-error' : ''); ?> ">
                                    <input type="text" name="mobile" class="form-control text-left" id="cell" placeholder="تلفن همراه" value="<?php echo e(Request::old('mobile') ?: ''); ?>" >
                                    <?php if($errors->has('mobile')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('mobile')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?> ">
                                    <input type="email" name="email" class="form-control text-left" id="email" placeholder="ایمیل" value="<?php echo e(Request::old('email') ?: ''); ?>">
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('email')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group username <?php echo e($errors->has('username') ? 'has-error' : ''); ?> ">
                                    <input type="text" name="username" class="form-control text-left" id="username" placeholder="نام کاربری" value="<?php echo e(Request::old('username') ?: ''); ?>">
                                    <span class="help-block username-message">
                                        <p>
                                            این نام کاربری موجود است
                                        </p>
                                    </span>
                                    <?php if($errors->has('username')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('username')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?> ">
                                    <input type="password" name="password" placeholder="رمز عبور" class="form-control text-left" id="pwd">
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('password')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <button type="submit" class="btn btn-success btn-block">ثبت نام</button>
                                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo e(Html::script('common/js/jquery/jquery.min.js')); ?>

    <?php echo e(Html::script('common/js/bootstrap/bootstrap.min.js')); ?>

    <?php echo e(Html::script('common/js/validator/formValidation.min.js')); ?>

    <?php echo e(Html::script('common/js/validator/bootstrapValidation.min.js')); ?>

    <?php echo e(Html::script('common/js/lang/lang-fa.js')); ?>

    <?php echo e(Html::script('frontend/js/auth/auth.js')); ?>

    <script>
    $(function(){
        $('body').on('change','#username',function(){
            $('.username').removeClass('has-error has-success');
            $.ajax({
                url: '<?php echo e(route('auth.userNameCheck')); ?>',
                type: 'POST',
                data: {
                    username: $('#username').val(),
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                error: function() {

                },
                dataType: 'json',
                success: function(data) {
                    if(data.message == 'failed')
                    {
                        $('.username').addClass('has-error');
                        $('.username-message').show();
                    }else{
                        $('.username').addClass('has-success');
                        $('.username-message').hide();
                    }
                },
            });
        });
    });
    </script>
</body>
</html>
