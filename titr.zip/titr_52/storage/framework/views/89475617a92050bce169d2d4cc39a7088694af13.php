<?php $__env->startSection('stylesheet'); ?>
  <?php echo e(Html::style('frontend/css/homepage/homepage.css')); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    
  <div class="col-md-3 no-padding">
    <aside class="sidebar">
      <div class="logo">
        <img src="<?php echo e(asset('frontend/img/logo2.png')); ?>" alt="" />
      </div>
      <nav class="nav-right">
        <ul class="nav nav-pills nav-stacked">
          <?php if(!is_null(Auth::user())): ?>
            <li role="presentation"><a href="#"><i class="fa fa-user fa-titr"></i><?php echo e(Auth::user()->name); ?><?php echo ' جان خوش آمدید'; ?></a></li>
          <?php endif; ?>
          <li role="presentation"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home fa-titr"></i>صفحه اصلی</a></li>
          <li role="presentation"><a href="<?php echo e(route('auth.signin')); ?>"><i class="fa fa-users fa-titr"></i>ورود</a></li>
          <li role="presentation"><a href="<?php echo e(route('auth.signup')); ?>"><i class="fa fa-plus fa-titr"></i>عضویت</a></li>
          <li role="presentation"><a href="#"><i class="fa fa-send fa-titr"></i>ارسال آگهی</a></li>
          <li role="presentation"><a href="#"><i class="fa fa-phone fa-titr"></i>تماس با ما</a></li>
          <li role="presentation"><a href="#"><i class="fa fa-envelope fa-titr"></i>ارتباط با ما</a></li>
          <?php if(!is_null(Auth::user())): ?>
            <li role="presentation"><a href="<?php echo e(route('auth.signout')); ?>"><i class="fa fa-sign-out fa-titr"></i>خروج</a></li>
          <?php endif; ?>
        </ul>
      </na>
    </aside>
  </div>
  <div class="col-md-9 no-padding">
    <section class="home">
      <div class="box">
        <div class="content">
          <h1 class="text-center">با یک تیتر هم میتونی بخری هم میتونی بفروشی</h1>
          <form class="form" action="index.html" method="post">
            <div class="form-group">
              <div class="col-sm-11 no-padding">
                <input type="text" name="search" class="form-control searchInput" placeholder="دنبال چه کتابی میگردی ؟ همین الان اسمشو بنویس و دنبالش بگرد">
              </div>
              <div class="col-sm-1 no-padding">
                <button type="button" name="searchSubmit" class="btn btn-success searchSubmit">
                  <i class="fa fa-2x fa-search"></i>
                </button>
              </div>
              <div class="clearfix">

              </div>
            </div>
          </form>
          <div class="clearfix">

          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend/layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>