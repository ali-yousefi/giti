<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo e(Html::style('common/css/bootstrap/bootstrap.min.css')); ?>

    <?php echo e(Html::style('common/css/bootstrap/bootstrap-rtl.min.css')); ?>

    <?php echo e(Html::style('common/css/font-awesome/font-awesome.min.css')); ?>    
    <?php echo e(Html::style('common/css/iransans/style.css')); ?>

    <?php echo $__env->yieldContent('stylesheet'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo e(Html::script('common/js/jquery/jquery.min.js')); ?>

    <?php echo e(Html::script('common/js/bootstrap/bootstrap.min.js')); ?>

    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
