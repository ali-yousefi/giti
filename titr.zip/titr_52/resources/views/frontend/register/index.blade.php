<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <title>یک تیتر | ثبت نام</title>
    {{ Html::style('common/css/bootstrap/bootstrap.min.css') }}
    {{ Html::style('common/css/bootstrap/bootstrap-rtl.min.css') }}
    {{ Html::style('common/css/font-awesome/font-awesome.min.css') }}
    {{ Html::style('common/css/iransans/style.css') }}
    {{ Html::style('frontend/css/auth/signup/signup.css') }}
    {{ Html::style('common/css/notify/notify.css') }}
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="col-md-4 col-lg-offset-4">
                    <div class="register-wrapper">
                        <div class="icon">
                            <img src="{{ asset('frontend/img/signup/icon.svg') }}" alt="" />
                            <h3>{{ __('register_in_titr') }}</h3>
                        </div>
                        <div class="form">
                            <form action="{{ route('auth.signup') }}" method="POST" class="form">
                                <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }} ">
                                    <input type="text" name="name" class="form-control" id="name" placeholder="{{ __('name') }}">
                                    @if($errors->has('name'))
                                        <span class="help-block">
                                            {{ $errors->first('name') }}
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group {{ $errors->has('family') ? 'has-error' : '' }} ">
                                    <input type="text" name="family" class="form-control" id="family" placeholder="{{ __('family') }}">
                                    @if($errors->has('family'))
                                        <span class="help-block">
                                            {{ $errors->first('family') }}
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group {{ $errors->has('state') ? 'has-error' : '' }} ">
                                    <select class="form-control" name="state">
                                        <option value="">{{ __('choose_a_one') }}</option>
                                        @foreach($states as $state)
                                            <option value="{{ $state->id }}" >{{ $state->name }}</option>
                                        @endforeach
                                    </select>
                                    @if($errors->has('state'))
                                        <span class="help-block">
                                            {{ $errors->first('state') }}
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group {{ $errors->has('mobile') ? 'has-error' : '' }} ">
                                    <input type="text" name="mobile" class="form-control text-left" id="cell" placeholder="{{ __('mobile') }}">
                                    @if($errors->has('mobile'))
                                        <span class="help-block">
                                            {{ $errors->first('mobile') }}
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }} ">
                                    <input type="email" name="email" class="form-control text-left" id="email" placeholder="{{ __('email') }}">
                                    @if($errors->has('email'))
                                        <span class="help-block">
                                            {{ $errors->first('email') }}
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group username {{ $errors->has('username') ? 'has-error' : '' }} ">
                                    <input type="text" name="username" class="form-control text-left" id="username" placeholder="{{ __('username') }}">
                                    <span class="help-block username-message">
                                        <p>
                                            {{ __('username_is_available') }}
                                        </p>
                                    </span>
                                    @if($errors->has('username'))
                                        <span class="help-block">
                                            {{ $errors->first('username') }}
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group {{ $errors->has('password') ? 'has-error' : '' }} ">
                                    <input type="password" name="password" placeholder="{{ __('password') }}" class="form-control text-left" id="pwd">
                                    @if($errors->has('password'))
                                        <span class="help-block">
                                            {{ $errors->first('password') }}
                                        </span>
                                    @endif
                                </div>
                                <button type="submit" class="btn btn-success btn-block">{{ __('register_in_titr') }}</button>
                                <input type="hidden" name="_token" value="{{ Session::token() }}">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{ Html::script('common/js/jquery/jquery.min.js') }}
    {{ Html::script('common/js/bootstrap/bootstrap.min.js') }}
    {{ Html::script('common/js/notify/notify.js') }}
    <script>
    $(function(){
        var myStack = {"dir1":"down", "dir2":"right", "push":"top"};
        new PNotify({
            title: "Over Here",
            text: "Check me out. I'm in a different stack.",
            addclass: "stack-custom",
            stack: myStack
        });
        $('body').on('change','#username',function(){
            $('.username').removeClass('has-error has-success');
            $.ajax({
                url: '{{ route('auth.userNameCheck') }}',
                type: 'POST',
                data: {
                    username: $('#username').val(),
                    _token: '{{ csrf_token() }}'
                },
                error: function() {

                },
                dataType: 'json',
                success: function(data) {
                    if(data.message == 'failed')
                    {
                        $('.username').addClass('has-error');
                        $('.username-message').show();
                    }else{
                        $('.username').addClass('has-success');
                        $('.username-message').hide();
                    }
                },
            });
        });
    });
    </script>
</body>
</html>
