<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <title>یک تیتر | ثبت نام</title>
    {{ Html::style('common/css/bootstrap/bootstrap.min.css') }}
    {{ Html::style('common/css/bootstrap/bootstrap-rtl.min.css') }}
    {{ Html::style('common/css/font-awesome/font-awesome.min.css') }}
    {{ Html::style('common/css/iransans/style.css') }}
    {{ Html::style('frontend/css/auth/signup/signup.css') }}
    {{ Html::style('common/css/notify/notify.css') }}
</head>
<body>      
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="col-md-4 col-lg-offset-4">
                    <div class="register-wrapper">
                        <div class="icon">
                            <img src="{{ asset('frontend/img/signup/icon.svg') }}" alt="" />
                            <h3>{{ __('signin_to_titr') }}</h3>
                        </div>
                        <div class="form">
                            <form class="form" role="form" method="POST" action="{{ route('auth.signin') }}" id="signinForm">
                                <div class="form-group username">
                                    <input type="text" name="username" class="form-control text-left" id="username" placeholder="{{ __('username') }}">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" placeholder="{{ __('password') }}" class="form-control text-left" id="pwd">
                                </div>
                                <div class="checkbox">
                                    <label><input type="checkbox">{{ __('remember_me') }}</label>
                                </div>
                                <button type="submit" class="btn btn-success btn-block">{{ __('signin') }}</button>
                                <a href="{{ route('auth.signup') }}" class="btn btn-info btn-block">{{ __('register') }}</a>
                                <a href="{{ route('auth.signup') }}" class="btn btn-default btn-block">{{ __('verify') }}</a>
                                <input type="hidden" name="_token" value="{{ Session::token() }}">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{ Html::script('common/js/jquery/jquery.min.js') }}
    {{ Html::script('common/js/bootstrap/bootstrap.min.js') }}
    {{ Html::script('common/js/validator/formValidation.min.js') }}
    {{ Html::script('common/js/validator/bootstrapValidation.min.js') }}
    {{ Html::script('common/js/lang/lang-fa.js') }}
    {{ Html::script('frontend/js/auth/auth.js') }}
    {{ Html::script('common/js/notify/notify.js') }}
    <script type="text/javascript">
        $('#username').focus();
    </script>
    @if(Session::has('register'))
        <script type="text/javascript">
        var myStack = {"dir1":"down", "dir2":"right", "push":"top"};
        new PNotify({
            type: 'success',
            text: "{{Session::get('register')}}",
            addclass: "stack-custom",
            stack: myStack
        })
        </script>
    @endif
    @if(Session::has('info'))
        <script type="text/javascript">
        var myStack = {"dir1":"down", "dir2":"right", "push":"top"};
        new PNotify({
            type: 'warning',
            text: "{{Session::get('info')}}",
            addclass: "stack-custom",
            stack: myStack
        })
        </script>
    @endif
</body>
</html>
