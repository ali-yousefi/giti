<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <title>@yield('title')</title>
    {{ Html::style('common/css/bootstrap/bootstrap.min.css') }}
    {{ Html::style('common/css/bootstrap/bootstrap-rtl.min.css') }}
    {{ Html::style('common/css/font-awesome/font-awesome.min.css') }}    
    {{ Html::style('common/css/iransans/style.css') }}
    @yield('stylesheet')
</head>
<body>
    @yield('content')
    {{ Html::script('common/js/jquery/jquery.min.js') }}
    {{ Html::script('common/js/bootstrap/bootstrap.min.js') }}
    @yield('script')
</body>
</html>
